﻿Public Class Rock_n_Roll_Commons

    Private colConfig As New System.Collections.Generic.Dictionary(Of String, String)

    Public Sub New()

        LoadConfig()

    End Sub

    Public Property SettingFor(sKey As String)

        Get
            On Error GoTo SettingForPropertyGetError
            SettingFor = colConfig(sKey)

SettingForPropertyGetError:
            On Error GoTo 0
        End Get

        Set(sValue)
            On Error GoTo SettingForPropertySetError
            colConfig(sKey) = sValue

SettingForPropertySetError:
            On Error GoTo 0
        End Set

    End Property

    Public Sub SaveSettings()

        Dim sLine As String = ""
        Dim flFileWriter As System.IO.StreamWriter
        Dim oPair As KeyValuePair(Of String, String)

        On Error GoTo SaveSettingsProcError
        If System.IO.File.Exists("RnRSettings.ini") Then System.IO.File.Delete("RnRSettings.ini")
        flFileWriter = IO.File.CreateText("RnRSettings.ini")
        flFileWriter.WriteLine("##############   Configuration file for RnR tools   ###################")
        flFileWriter.WriteLine("#   this file has been created by RnR Config Manager")
        flFileWriter.WriteLine("#   however you can modify this file manually the better way is to use RnR Config Manager")
        flFileWriter.WriteLine("##############   ###################")
        flFileWriter.WriteLine("")
        For Each oPair In colConfig
            flFileWriter.WriteLine(oPair.Key & " = " & oPair.Value)
        Next
        flFileWriter.Close()

SaveSettingsProcError:
        If Err.Number <> 0 Then
            SaveToLog(Err.Number & " - " & Err.Description)
        Else
            SaveToLog("New settings saved to RnRSettings.ini")
        End If
        On Error GoTo 0

    End Sub

    Public Sub SaveToLog(sText As String)

        Dim flFW As System.IO.StreamWriter
        Dim sLogFileName As String = colConfig("LogsDirectory") & "\" & Strings.Format(Now, "yyyyMMdd") & ".txt"

        On Error GoTo SaveToLogProcError
        If UCase(colConfig("LogsEnabled")) = "TRUE" Then
            If Not System.IO.Directory.Exists(colConfig("LogsDirectory")) Then System.IO.Directory.CreateDirectory(colConfig("LogsDirectory"))
            flFW = System.IO.File.AppendText(sLogFileName)
            flFW.WriteLine(Strings.Format(Now, "[HH:mm:ss] - " & sText))
            flFW.Close()
        End If

SaveToLogProcError:
        On Error GoTo 0

    End Sub

    Private Sub LoadConfig()
        'loads config collection with saved values or default
        Dim sLine As String = ""
        Dim flFileReader As System.IO.StreamReader
        Dim oPair As KeyValuePair(Of String, String)

        On Error GoTo LoadConfigProcError
        'load default settings into collection
        With colConfig
            'server applying settings
            .Add("PHPExecutableDirectory", Application.StartupPath & "\PHP") 'sets default PHP path to {AppInstallDirectory}\PHP
            .Add("ServerInterface", "0.0.0.0") ' listen on all interfaces as default
            .Add("ServerPort", "8000")
            .Add("PHPApplicationDirectory", Application.StartupPath & "\App") 'sets default aplication directory to {AppInstallDirectory}\App
            'logs
            .Add("LogsEnabled", "false")
            .Add("LogsDirectory", Application.StartupPath & "\Logs") 'sets logs default directory to {AppInstallDirectory}\Logs
            .Add("LogsKeepDays", "15") 'how many days logs are stored
            'viewer applying settings
            .Add("WebBrowser", "built-in") ' available values: built-in, customized IE, system default, IE, Chrome, Firefox, Opera, Safari
            .Add("WebBrowserStartOptions", "")
            'setting for customized Internet explorer if selected
            .Add("CustomIE_AddressBar", "false")
            .Add("CustomIE_MenuBar", "false")
            .Add("CustomIE_ToolBar", "false")
            .Add("CustomIE_Resizable", "false")
            .Add("CustomIE_Left", "100") ' -1 means IE default
            .Add("CustomIE_Top", "100")
            .Add("CustomIE_Width", "240")
            .Add("CustomIE_Height", "600")
            'settings for builtin web browser
            '.Add("BuiltInWebBrowser_Icon", "")
            .Add("BuiltInWebBrowser_Title", "My Application")
            .Add("BuiltInWebBrowser_Resizable", "true")
            .Add("BuiltInWebBrowser_StartMaximized", "false")
            .Add("BuiltInWebBrowser_Left", "-1") ' -1 means last used before close
            .Add("BuiltInWebBrowser_Top", "-1")
            .Add("BuiltInWebBrowser_Width", "-1")
            .Add("BuiltInWebBrowser_Height", "-1")
        End With

        If System.IO.File.Exists("RnRSettings.ini") Then
            'sSettings = System.IO.File.ReadAllText("RnRSettings.ini")
            flFileReader = IO.File.OpenText("RnRSettings.ini")
            Do While Not flFileReader.EndOfStream
                sLine = flFileReader.ReadLine
                If Left(sLine, 1) <> "/" And Left(sLine, 1) <> ";" And Left(sLine, 1) <> "#" Then
                    For Each oPair In colConfig
                        If InStr(oPair.Key, sLine) Then
                            FetchConfigString(oPair.Key, sLine)
                            Exit For
                        End If
                    Next
                End If

            Loop
        End If

LoadConfigProcError:
        On Error GoTo 0

    End Sub

    Private Function FetchConfigString(ByVal sKey As String, ByRef sSettings As String) As String
        'this function searches for sKey in given sSettings and returns string 
        Dim iX1 As Integer = 0
        Dim iX2 As Integer = 0
        Dim sTmp As String = ""

        On Error GoTo FetchConfigStringProcError
        If Len(sKey) > 0 AndAlso Len(sSettings) > 0 AndAlso Len(sSettings) > Len(sKey) Then
            iX1 = Strings.InStr(sSettings, sKey)
            iX2 = Strings.InStr(iX1, sSettings, vbCrLf)
            If (iX1 > 0) AndAlso (iX2 > (iX1 + Len(sKey) + 1)) Then 'searched key has been found
                sTmp = Strings.Mid(sSettings, iX1, iX2)
                sTmp = Strings.Replace(sTmp, sKey, "") ' remove searched key from the string
                sTmp = Strings.Replace(sTmp, "=", "") ' remove '='  the string
                sTmp = Strings.Trim(sTmp)
            End If
        End If

FetchConfigStringProcError:
        On Error GoTo 0
        FetchConfigString = sTmp

    End Function


End Class
