<br><b><h2>It works!</h2></b><br><br>
Your <i>DocumentRoot</i> is: <b><? echo getcwd();?>.</b><br>
This text is from {<i>DocumentRoot</i>}<b>\index.php.</b><br>
Replace it with your PHP application.<br><br>
Use <i><b>Config Manager </b></i> to customize settings.<br><br>
To get the smallest PHP application and easy to distribute, try to use <b><i><a href="https://www.sqlite.org" target="new">SQLite</a></i></b> - a single file database instead of installing a big database server.<br>
(take a look at their license)<br><br><br>
<b>License: </b><i><br>
(applies to Rock'n'Roll software ver. 1.0.* and does not apply to <b><a href="https://php.net" target="new">PHP</a></b> software)</i><br>
You can use Rock'n'Roll software, modify sources, add, distribute and sell with your applications. Everything free, but do not forget to mention that your software is built on rock'n'roll :)<br><br>
That's all.<br><br>
Rob Trasko from trasko.net<br><br><br>
-----<br>
<i><b>SQLite</b> and <b>PHP</b> names are owned by their respective owners</i>





