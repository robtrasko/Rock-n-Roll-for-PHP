﻿Public Class RnRService

    Public Enum ServiceState
        SERVICE_STOPPED = 1
        SERVICE_START_PENDING = 2
        SERVICE_STOP_PENDING = 3
        SERVICE_RUNNING = 4
        SERVICE_CONTINUE_PENDING = 5
        SERVICE_PAUSE_PENDING = 6
        SERVICE_PAUSED = 7
    End Enum

    '<StructLayout(LayoutKind.Sequential)>
    Public Structure ServiceStatus
        Public dwServiceType As Long
        Public dwCurrentState As ServiceState
        Public dwControlsAccepted As Long
        Public dwWin32ExitCode As Long
        Public dwServiceSpecificExitCode As Long
        Public dwCheckPoint As Long
        Public dwWaitHint As Long
    End Structure

    Private WithEvents ProcServer As New Process
    Private RnR As New Rock_n_Roll_Commons

    Declare Auto Function SetServiceStatus Lib "advapi32.dll" (ByVal handle As IntPtr, ByRef serviceStatus As ServiceStatus) As Boolean

    Protected Overrides Sub OnStart(ByVal args() As String)

        If Not LaunchRnRServerService() Then Me.Stop()

    End Sub

    Protected Overrides Sub OnStop()

        StopService()

    End Sub

    Private Sub StopService()

        Try
            ProcServer.Kill()
        Catch ex As Exception
            RnR.SaveToLog("Can not stop the CLI. Error: " & Err.Description)
        End Try

        RnR.SaveToLog("Rock'n'Roll Server stopped.")

    End Sub

    Private Sub ServerProcess_Exited(sender As Object, e As EventArgs) Handles ServerProcess.Exited

        StopService()

    End Sub

    Private Function LaunchRnRServerService() As Boolean
        'returns true if embeded php server started
        Dim ServerExe As String = RnR.SettingFor("PHPExecutableDirectory") & "\php.exe"
        Dim InitOptions As String = "-S " & RnR.SettingFor("ServerInterface") & ":" & RnR.SettingFor("ServerPort") & " -t " & RnR.SettingFor("PHPApplicationDirectory")
        Dim PHPServerStarted As Boolean = False ' error on start as default
        Dim LogText As String = ""

        If Not System.IO.File.Exists(ServerExe) Then LogText = "The file " & ServerExe & " does not exist."
        If Not System.IO.File.Exists(RnR.SettingFor("PHPApplicationDirectory") & "\index.php") Then
            If Len(LogText) Then LogText = LogText & vbCrLf
            LogText = LogText & "The file " & RnR.SettingFor("PHPApplicationDirectory") & "\index.php" & " does not exist."
        End If
        If Len(LogText) = 0 Then
            Try
                With ProcServer.StartInfo
                    .FileName = ServerExe
                    .Arguments = InitOptions
                    .UseShellExecute = False
                    .CreateNoWindow = True
                    .WindowStyle = ProcessWindowStyle.Hidden
                    .RedirectStandardInput = True
                    .RedirectStandardOutput = True
                    .RedirectStandardError = True
                End With
                ProcServer.Start()
                ProcServer.BeginErrorReadLine()
                ProcServer.BeginOutputReadLine()
                LogText = "Rock'n'Roll Server started as a Windows service" & vbCrLf
                LogText = LogText & "Server is listening on: " & RnR.SettingFor("ServerInterface") & ":" & RnR.SettingFor("ServerPort") & vbCrLf
                LogText = LogText & "Application root directory is: " & RnR.SettingFor("PHPApplicationDirectory")
                PHPServerStarted = True
            Catch ex As Exception
                LogText = vbCrLf & "Can't start RnR server as a Windows service. Error: " & Err.Description & vbCrLf & LogText
            End Try
        End If

        RnR.SaveToLog(LogText)
        Return PHPServerStarted  ' service started without errors

    End Function

    Private Sub ProcServer_Exited(sender As Object, e As EventArgs) Handles ProcServer.Exited
        SendStopSignalToServiceController()
    End Sub

    Private Sub SendStopSignalToServiceController()
        'Dim ServerStatus As ServiceStatus

        'ServerStatus.dwCurrentState = ServiceState.SERVICE_STOPPED
        'SetServiceStatus(Me.ServiceHandle, ServerStatus)
        ServerProcess.Close()
        Me.Stop()

    End Sub

    Private Sub ProcServer_ErrorDataReceived(sender As Object, e As DataReceivedEventArgs) Handles ProcServer.ErrorDataReceived
        SendStopSignalToServiceController()
    End Sub

    Private Sub ProcServer_Disposed(sender As Object, e As EventArgs) Handles ProcServer.Disposed
        SendStopSignalToServiceController()
    End Sub
End Class
