﻿Imports System.ServiceProcess

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RnRService
    Inherits System.ServiceProcess.ServiceBase

    'UserService przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    ' Główny punkt wejścia dla procesu
    <MTAThread()>
    <System.Diagnostics.DebuggerNonUserCode()>
    Shared Sub Main(ByVal cmdArgs() As String)
        Dim ServicesToRun() As System.ServiceProcess.ServiceBase = New System.ServiceProcess.ServiceBase() {New RnRService(cmdArgs)}

        System.ServiceProcess.ServiceBase.Run(ServicesToRun)
        ' Więcej niż jedna usługa NT może działać w ramach tego samego procesu. Aby dodać
        ' kolejną usługę do tego procesu, zmień następną linię, aby
        ' utworzyć drugi obiekt usługi. Na przykład,

    End Sub

    'Wymagane przez Projektanta składników
    Private components As System.ComponentModel.IContainer

    ' UWAGA: Następująca procedura jest wymagana przez Projektanta składników
    ' Można to modyfikować za pomocą Projektanta składników.  
    ' Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ServerProcess = New System.Diagnostics.Process()
        '
        'ServerProcess
        '
        Me.ServerProcess.StartInfo.Domain = ""
        Me.ServerProcess.StartInfo.LoadUserProfile = False
        Me.ServerProcess.StartInfo.Password = Nothing
        Me.ServerProcess.StartInfo.StandardErrorEncoding = Nothing
        Me.ServerProcess.StartInfo.StandardOutputEncoding = Nothing
        Me.ServerProcess.StartInfo.UserName = ""
        '
        '
        'RnRService
        '
        Me.ServiceName = "Rock and Roll Server"

    End Sub

    Friend WithEvents ServerProcess As Process
    Private cmdArgs As String()

    Public Sub New(cmdArgs() As String)
        MyBase.New()
        InitializeComponent()
        Me.cmdArgs = cmdArgs
    End Sub
End Class
