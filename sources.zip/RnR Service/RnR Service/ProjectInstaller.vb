﻿Imports System.ComponentModel
Imports System.Configuration.Install

Public Class ProjectInstaller

    Public Sub New()
        MyBase.New()

        'To wywołanie jest wymagane przez Projektanta składników.
        InitializeComponent()

        'Dodaj kod inicjujący po wywołaniu funkcji InitializeComponent

    End Sub

End Class
