﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.tb = New System.Windows.Forms.TabControl()
        Me.tbPageServer = New System.Windows.Forms.TabPage()
        Me.tbPageBrowser = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPHPExecutableDirectory = New System.Windows.Forms.TextBox()
        Me.tb.SuspendLayout()
        Me.tbPageServer.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(725, 40)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(120, 37)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(727, 93)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(120, 36)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'tb
        '
        Me.tb.Controls.Add(Me.tbPageServer)
        Me.tb.Controls.Add(Me.tbPageBrowser)
        Me.tb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tb.Location = New System.Drawing.Point(12, 12)
        Me.tb.Name = "tb"
        Me.tb.SelectedIndex = 0
        Me.tb.Size = New System.Drawing.Size(693, 565)
        Me.tb.TabIndex = 4
        '
        'tbPageServer
        '
        Me.tbPageServer.Controls.Add(Me.GroupBox1)
        Me.tbPageServer.Location = New System.Drawing.Point(4, 25)
        Me.tbPageServer.Name = "tbPageServer"
        Me.tbPageServer.Padding = New System.Windows.Forms.Padding(3)
        Me.tbPageServer.Size = New System.Drawing.Size(685, 536)
        Me.tbPageServer.TabIndex = 0
        Me.tbPageServer.Text = "Server"
        Me.tbPageServer.UseVisualStyleBackColor = True
        '
        'tbPageBrowser
        '
        Me.tbPageBrowser.Location = New System.Drawing.Point(4, 25)
        Me.tbPageBrowser.Name = "tbPageBrowser"
        Me.tbPageBrowser.Padding = New System.Windows.Forms.Padding(3)
        Me.tbPageBrowser.Size = New System.Drawing.Size(685, 536)
        Me.tbPageBrowser.TabIndex = 1
        Me.tbPageBrowser.Text = "Browser"
        Me.tbPageBrowser.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPHPExecutableDirectory)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(673, 117)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PHP exe directory"
        '
        'txtPHPExecutableDirectory
        '
        Me.txtPHPExecutableDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.txtPHPExecutableDirectory.Location = New System.Drawing.Point(139, 18)
        Me.txtPHPExecutableDirectory.Name = "txtPHPExecutableDirectory"
        Me.txtPHPExecutableDirectory.Size = New System.Drawing.Size(487, 20)
        Me.txtPHPExecutableDirectory.TabIndex = 1
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(859, 589)
        Me.Controls.Add(Me.tb)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormMain"
        Me.Text = "Rock'n'Roll Config Manager"
        Me.tb.ResumeLayout(False)
        Me.tbPageServer.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnSave As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents tb As TabControl
    Friend WithEvents tbPageServer As TabPage
    Friend WithEvents tbPageBrowser As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtPHPExecutableDirectory As TextBox
    Friend WithEvents Label1 As Label
End Class
