﻿Public Class FormMain

    Private RnRSettings As New Rock_n_Roll_Commons
    Private bDisplayWarning = True
    Dim WithEvents sc As ServiceProcess.ServiceController

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        End
    End Sub

    Private Sub BtnPHPDirectory_Click(sender As Object, e As EventArgs) Handles BtnPHPDirectory.Click

        Dim OpenFolderWindow As New FolderBrowserDialog

        Try
            With OpenFolderWindow
                .SelectedPath = Application.StartupPath
                .ShowNewFolderButton = False
                .Description = "Select PHP root directory."
                .ShowDialog()
                If System.IO.File.Exists(.SelectedPath & "\php.exe") Then
                    Me.lblPHPExeDirectory.Text = .SelectedPath
                Else
                    MsgBox("The selected path does not contain PHP executable (php.exe) file", MsgBoxStyle.OkOnly + MsgBoxStyle.ApplicationModal + MsgBoxStyle.Exclamation, Me.Text)
                End If
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub ChkLogs_CheckedChanged(sender As Object, e As EventArgs) Handles ChkLogs.CheckedChanged

        Me.lblLogDirectory.Enabled = Me.ChkLogs.Checked
        Me.BtnLogDirectory.Enabled = Me.ChkLogs.Checked

    End Sub

    Private Sub ChkServerAsService_CheckedChanged(sender As Object, e As EventArgs) Handles ChkServerAsService.CheckedChanged

        ChkServerAsService.BackColor = ChkLogs.BackColor
        ChkStartWithInternalWebServer.BackColor = ChkLogs.BackColor
        If ChkStartWithInternalWebServer.Checked And ChkServerAsService.Checked And Me.Visible And bDisplayWarning Then
            ChkServerAsService.BackColor = Color.Orange
            ChkStartWithInternalWebServer.BackColor = Color.Orange
            MsgBox("<Start browser with built-in web server> is selected!. " & vbCrLf & vbCrLf & "To avoid server's conflict, uncheck it before Windows service start.", MsgBoxStyle.OkOnly + MsgBoxStyle.ApplicationModal + MsgBoxStyle.Exclamation, Me.Text)
            bDisplayWarning = False
            'ChkServerAsService.Checked = False
        Else
            With Me
                .TxtServiceName.Enabled = .ChkServerAsService.Checked
                .BtnInstallService.Enabled = .ChkServerAsService.Checked
                .BtnRunService.Enabled = .ChkServerAsService.Checked
                .BtnStopService.Enabled = .ChkServerAsService.Checked
                .BtnUninstallService.Enabled = .ChkServerAsService.Checked
            End With
        End If

        EnableServiceButtons()

    End Sub

    Private Sub BtnMyAppDirectory_Click(sender As Object, e As EventArgs) Handles BtnMyAppDirectory.Click

        Dim OpenFolderWindow As New FolderBrowserDialog

        Try
            With OpenFolderWindow
                .SelectedPath = Application.StartupPath
                .ShowNewFolderButton = True
                .Description = "Directory to my PHP application"
                .ShowDialog()
                Me.lblPHPApplicationDirectory.Text = .SelectedPath
                If Not System.IO.File.Exists(.SelectedPath & "\index.php") Then
                    MsgBox("The index.php file does not exist in selected folder. " & vbCrLf & "Remember to create.", MsgBoxStyle.OkOnly + MsgBoxStyle.ApplicationModal + MsgBoxStyle.Information, Me.Text)
                End If
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub ChkStartWithInternalWebServer_CheckedChanged(sender As Object, e As EventArgs) Handles ChkStartWithInternalWebServer.CheckedChanged

        ChkServerAsService.BackColor = ChkLogs.BackColor
        ChkStartWithInternalWebServer.BackColor = ChkLogs.BackColor
        If ChkStartWithInternalWebServer.Checked And ChkServerAsService.Checked And Me.Visible And bDisplayWarning Then
            ChkServerAsService.BackColor = Color.Orange
            ChkStartWithInternalWebServer.BackColor = Color.Orange
            MsgBox("<Run server as a Windows service> is selected!. " & vbCrLf & vbCrLf & "To avoid server's conflict, only one should be checked.", MsgBoxStyle.OkOnly + MsgBoxStyle.ApplicationModal + MsgBoxStyle.Exclamation, Me.Text)
            bDisplayWarning = False
        End If
        ChkStartWithConsole.Enabled = ChkStartWithInternalWebServer.Checked

    End Sub

    Private Sub CboWebBrowser_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboWebBrowser.SelectedIndexChanged

        GrpCustomIE.Hide()
        GrpInternalWebBrowser.Hide()
        TxtStartOptions.Enabled = False

        Select Case CboWebBrowser.SelectedIndex
            Case 0                 'built-in webbrowser selected
                GrpInternalWebBrowser.Show()
                GrpInternalWebBrowser.BringToFront()
            Case 1                 'customized IE selected
                GrpCustomIE.Show()
                GrpCustomIE.BringToFront()
            Case 2                 'sytem default browser selected
                TxtStartOptions.Enabled = True
        End Select


    End Sub

    Private Sub EnableServiceButtons()
        'enables or disables service buttons depend on service controller status
        DisableServiceButtons()
        If ChkServerAsService.Checked Then
            If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
                'App is running as an administrator
                Try
                    sc = New ServiceProcess.ServiceController("Rock and Roll Server", ".")
                    If Not IsNothing(sc.ServiceName) Then
                        BtnUninstallService.Enabled = True
                        If sc.Status = ServiceProcess.ServiceControllerStatus.Paused Or sc.Status = ServiceProcess.ServiceControllerStatus.Stopped Or sc.Status = ServiceProcess.ServiceControllerStatus.StopPending Then
                            BtnRunService.Enabled = True
                        ElseIf sc.Status = ServiceProcess.ServiceControllerStatus.StartPending Or sc.Status = ServiceProcess.ServiceControllerStatus.Running Then
                            BtnStopService.Enabled = True
                        End If
                    End If
                Catch ex As Exception
                    BtnInstallService.Enabled = True
                    sc = Nothing
                End Try
            Else
                'App is NOT running as an administrator
                PromptForAdmin()
            End If
        Else
                sc = Nothing
        End If

    End Sub

    Private Sub DisableServiceButtons()
        BtnInstallService.Enabled = False
        BtnUninstallService.Enabled = False
        BtnRunService.Enabled = False
        BtnStopService.Enabled = False
    End Sub

    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GrpInternalWebBrowser.Left = GrpCustomIE.Left
        GrpInternalWebBrowser.Top = GrpCustomIE.Top
        LoadSettingsIntoComponents()
        If My.User.IsInRole(ApplicationServices.BuiltInRole.Administrator) Then
            'if app is running in administrator mode
            LblNonAdminMode.Visible = False
            ChkServerAsService.Enabled = True
            TxtServiceName.ReadOnly = False
        Else
            LblNonAdminMode.Visible = True
            ChkServerAsService.Enabled = False
            TxtServiceName.ReadOnly = True
        End If
    End Sub
    Private Sub BtnLogDirectory_Click(sender As Object, e As EventArgs) Handles BtnLogDirectory.Click

        Dim OpenFolderWindow As New FolderBrowserDialog

        Try
            With OpenFolderWindow
                .SelectedPath = Application.StartupPath
                .ShowNewFolderButton = True
                .Description = "Directory to log files"
                .ShowDialog()
                Me.lblLogDirectory.Text = .SelectedPath
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub LoadSettingsIntoComponents()

        Try
            With RnRSettings
                lblPHPExeDirectory.Text = .SettingFor("PHPExecutableDirectory")
                lblPHPApplicationDirectory.Text = .SettingFor("PHPApplicationDirectory")
                CboServerInterface.Text = .SettingFor("ServerInterface")
                UpDnServerPort.Value = Val(.SettingFor("ServerPort"))
                ChkServerAsService.Checked = Convert.ToBoolean(.SettingFor("RunAsWindowsService"))
                TxtServiceName.Text = .SettingFor("WindowsServiceName")
                ChkLogs.Checked = Convert.ToBoolean(.SettingFor("LogsEnabled"))
                lblLogDirectory.Text = .SettingFor("LogsDirectory")
                ChkStartWithInternalWebServer.Checked = Convert.ToBoolean(.SettingFor("BrowserStartsWithBuiltInServer"))
                ChkStartWithConsole.Checked = Convert.ToBoolean(.SettingFor("BrowserStartsWithServerConsole"))
                Select Case UCase(.SettingFor("Browser"))
                    'available values
                    Case "BUILT-IN"
                        CboWebBrowser.SelectedIndex = 0
                    Case "CUSTOMIZEDIE"
                        CboWebBrowser.SelectedIndex = 1
                    Case "DEFAULT"
                        CboWebBrowser.SelectedIndex = 2
                        'Case "IEXPLORE"
                        '   CboWebBrowser.SelectedIndex = 3
                        'Case "FIREFOX"
                        '    CboWebBrowser.SelectedIndex = 4
                        'Case "CHROME"
                        '   CboWebBrowser.SelectedIndex = 5
                        'Case "OPERA"
                        '   CboWebBrowser.SelectedIndex = 6
                        'Case "SAFARI"
                        '   CboWebBrowser.SelectedIndex = 7
                    Case Else
                        CboWebBrowser.SelectedIndex = 0
                        'CboWebBrowser.Text = .SettingFor("WebBrowser")
                End Select
                TxtStartOptions.Text = .SettingFor("BrowserStartOptions")
                TxtNavigate2.Text = .SettingFor("BrowserNavigate2")
                UpDnNawigate2Port.Value = Val(.SettingFor("BrowserNavigate2Port"))
                ChkAddressBarIE.Checked = Convert.ToBoolean(.SettingFor("CustomIE_AddressBar"))
                ChkMenuBarIE.Checked = Convert.ToBoolean(.SettingFor("CustomIE_MenuBar"))
                ChkToolBarIE.Checked = Convert.ToBoolean(.SettingFor("CustomIE_ToolBar"))
                ChkStatusBarIE.Checked = Convert.ToBoolean(.SettingFor("CustomIE_StatusBar"))
                ChkResizableIE.Checked = Convert.ToBoolean(.SettingFor("CustomIE_Resizable"))
                UpDnIE_Left.Value = Val(.SettingFor("CustomIE_Left"))
                UpDnIE_Top.Value = Val(.SettingFor("CustomIE_Top"))
                UpDnIE_Width.Value = Val(.SettingFor("CustomIE_Width"))
                UpDnIE_Height.Value = Val(.SettingFor("CustomIE_Height"))
                TxtApplicationTitle.Text = .SettingFor("BuiltInMyBrowser_Title")
                LblLogoFile.Text = .SettingFor("BuiltInMyBrowser_Logo")
                ChkResizableIB.Checked = Convert.ToBoolean(.SettingFor("BuiltInMyBrowser_Resizable"))
                ChkStartMaximizedIB.Checked = Convert.ToBoolean(.SettingFor("BuiltInMyBrowser_StartMaximized"))
                UpDownIB_Left.Value = Val(.SettingFor("BuiltInMyBrowser_Left"))
                UpDownIB_Top.Value = Val(.SettingFor("BuiltInMyBrowser_Top"))
                UpDownIB_Width.Value = Val(.SettingFor("BuiltInMyBrowser_Width"))
                UpDownIB_Height.Value = Val(.SettingFor("BuiltInMyBrowser_Height"))
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Err.Clear()
        Try
            With RnRSettings
                .Clear()
                .SettingFor("PHPExecutableDirectory") = lblPHPExeDirectory.Text
                .SettingFor("PHPApplicationDirectory") = lblPHPApplicationDirectory.Text
                .SettingFor("ServerInterface") = CboServerInterface.Text
                .SettingFor("ServerPort") = UpDnServerPort.Value
                .SettingFor("RunAsWindowsService") = ChkServerAsService.Checked.ToString
                .SettingFor("WindowsServiceName") = TxtServiceName.Text
                .SettingFor("LogsEnabled") = ChkLogs.Checked.ToString
                .SettingFor("LogsDirectory") = lblLogDirectory.Text
                .SettingFor("BrowserStartsWithBuiltInServer") = ChkStartWithInternalWebServer.Checked.ToString
                .SettingFor("BrowserStartsWithServerConsole") = ChkStartWithConsole.Checked.ToString
                Select Case CboWebBrowser.SelectedIndex
                    'available values
                    Case 0 ' "BUILT-IN"
                        .SettingFor("Browser") = "built-in"
                    Case 1 '"CUSTOMIZEDIE"
                        .SettingFor("Browser") = "customizedIE"
                    Case 2 '"DEFAULT"
                        .SettingFor("Browser") = "default"
                        'Case "IEXPLORE"
                        '   CboWebBrowser.SelectedIndex = 3
                        'Case "FIREFOX"
                        '    CboWebBrowser.SelectedIndex = 4
                        'Case "CHROME"
                        '   CboWebBrowser.SelectedIndex = 5
                        'Case "OPERA"
                        '   CboWebBrowser.SelectedIndex = 6
                        'Case "SAFARI"
                        '   CboWebBrowser.SelectedIndex = 7
                    Case Else
                        .SettingFor("Browser") = "built-in"
                        'CboWebBrowser.Text = .SettingFor("WebBrowser")
                End Select
                .SettingFor("BrowserStartOptions") = TxtStartOptions.Text
                If Len(Trim(TxtNavigate2.Text)) < 2 Then
                    .SettingFor("BrowserNavigate2") = "http://localhost"
                Else
                    .SettingFor("BrowserNavigate2") = TxtNavigate2.Text
                End If
                .SettingFor("BrowserNavigate2Port") = UpDnNawigate2Port.Value
                .SettingFor("CustomIE_AddressBar") = ChkAddressBarIE.Checked.ToString
                .SettingFor("CustomIE_MenuBar") = ChkMenuBarIE.Checked.ToString
                .SettingFor("CustomIE_ToolBar") = ChkToolBarIE.Checked.ToString
                .SettingFor("CustomIE_StatusBar") = ChkStatusBarIE.Checked.ToString
                .SettingFor("CustomIE_Resizable") = ChkResizableIE.Checked.ToString
                .SettingFor("CustomIE_Left") = UpDnIE_Left.Value
                .SettingFor("CustomIE_Top") = UpDnIE_Top.Value
                .SettingFor("CustomIE_Width") = UpDnIE_Width.Value
                .SettingFor("CustomIE_Height") = UpDnIE_Height.Value
                .SettingFor("BuiltInMyBrowser_Title") = TxtApplicationTitle.Text
                .SettingFor("BuiltInMyBrowser_Logo") = LblLogoFile.Text
                .SettingFor("BuiltInMyBrowser_Resizable") = ChkResizableIB.Checked.ToString
                .SettingFor("BuiltInMyBrowser_StartMaximized") = ChkStartMaximizedIB.Checked.ToString
                .SettingFor("BuiltInMyBrowser_Left") = UpDownIB_Left.Value
                .SettingFor("BuiltInMyBrowser_Top") = UpDownIB_Top.Value
                .SettingFor("BuiltInMyBrowser_Width") = UpDownIB_Width.Value
                .SettingFor("BuiltInMyBrowser_Height") = UpDownIB_Height.Value
                .SaveSettings()
            End With
            lblSaved.Visible = True
            Me.Refresh()
            Threading.Thread.Sleep(1000)
        Catch ex As Exception
            If Err.Number <> 0 Then
                MsgBox("An error no: " & Err.Number & " occured." & vbCrLf & Err.Description, MsgBoxStyle.Exclamation + MsgBoxStyle.ApplicationModal + MsgBoxStyle.OkOnly, "Error !!!")
            End If
        End Try

        RnRSettings = Nothing
        End

    End Sub

    Private Sub BtnRunService_Click(sender As Object, e As EventArgs) Handles BtnRunService.Click
        DisableServiceButtons()
        StartStopService()
        EnableServiceButtons()
    End Sub

    Private Sub StartStopService(Optional bStart As Boolean = True)
        Try
            Me.Cursor = Cursors.WaitCursor
            If bStart Then 'if start service
                If Not (sc.Status = ServiceProcess.ServiceControllerStatus.Running Or sc.Status = ServiceProcess.ServiceControllerStatus.StartPending) Then
                    sc.Start()
                    sc.WaitForStatus(ServiceProcess.ServiceControllerStatus.Running, TimeSpan.FromSeconds(30))
                End If
            Else 'if stop service
                If Not (sc.Status = ServiceProcess.ServiceControllerStatus.StartPending Or sc.Status = ServiceProcess.ServiceControllerStatus.Stopped) Then
                    sc.Stop()
                    sc.WaitForStatus(ServiceProcess.ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30))
                End If
            End If
        Catch ex As Exception
            Me.Cursor = Me.DefaultCursor
            PromptForAdmin()
        End Try
        Me.Cursor = Me.DefaultCursor
    End Sub

    Private Sub BtnStopService_Click(sender As Object, e As EventArgs) Handles BtnStopService.Click
        DisableServiceButtons()
        StartStopService(False)
        EnableServiceButtons()
    End Sub

    Private Sub PromptForAdmin()
        MsgBox("To manage Windows services run 'Config Manager' as an Administrator.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Config Manager")
    End Sub

    Private Sub BtnInstallService_Click(sender As Object, e As EventArgs) Handles BtnInstallService.Click

        ServiceInstalUninstall()

    End Sub

    Private Sub ServiceInstalUninstall(Optional ByVal bInstall As Boolean = True)
        'procedure is installing / uninstalling (bInstall = true or false) RnR Service.exe application as a Windows service
        Dim sWinDir As String = My.Computer.FileSystem.GetParentPath(Environment.SystemDirectory)
        Dim sUtilTooll As String = "" 'path to .NET InstallUtil.exe tool 
        Dim UtilProc As System.Diagnostics.Process

        DisableServiceButtons()
        If System.IO.File.Exists(sWinDir & "\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe") Then ' search 64-bit version
            sUtilTooll = sWinDir & "\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe"
        ElseIf System.IO.File.Exists(sWinDir & "\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe") Then ' search 32-bit version
            sUtilTooll = sWinDir & "\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe"
        End If
        If Not bInstall Then StartStopService(False) 'if for uninstall stop service first
        If Len(sUtilTooll) > 0 Then
            Me.Cursor = Cursors.WaitCursor
            Try
                UtilProc = New Process
                With UtilProc.StartInfo
                    .FileName = sUtilTooll
                    If bInstall Then
                        .Arguments = Chr(34) & Application.StartupPath & "\RnR Service.exe" & Chr(34)
                    Else
                        .Arguments = "/u " & Chr(34) & Application.StartupPath & "\RnR Service.exe" & Chr(34)
                    End If
                    .CreateNoWindow = True
                    .WindowStyle = ProcessWindowStyle.Hidden
                End With
                UtilProc.Start()
                UtilProc.WaitForExit(30000)
                Me.Cursor = Me.DefaultCursor
            Catch ex As Exception
                Me.Cursor = Me.DefaultCursor
                MsgBox("Problem with installing service. Details in " & Application.StartupPath & "\InstallUtil.InstallLog file.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Config Manager")
            End Try

        Else 'InstallUtil.exe has not been found
            MsgBox("Can not find .NET ver 4.x InstallUtil.exe tool. Please install .NET ver 4.x", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "Config Manager")
        End If
        Me.Cursor = Me.DefaultCursor
        EnableServiceButtons()
        UtilProc = Nothing


    End Sub

    Private Sub BtnUninstallService_Click(sender As Object, e As EventArgs) Handles BtnUninstallService.Click
        ServiceInstalUninstall(False)
    End Sub

    Private Sub ComparePorts()
        'light when serverPOrt and browserport are differnt
        If UpDnNawigate2Port.Value <> UpDnServerPort.Value Then
            UpDnServerPort.BackColor = Color.PaleGreen
            UpDnNawigate2Port.BackColor = Color.PaleGreen
        Else
            UpDnServerPort.BackColor = CboServerInterface.BackColor
            UpDnNawigate2Port.BackColor = CboServerInterface.BackColor
        End If
    End Sub

    Private Sub UpDnNawigate2Port_ValueChanged(sender As Object, e As EventArgs) Handles UpDnNawigate2Port.ValueChanged
        ComparePorts()
    End Sub

    Private Sub UpDnServerPort_ValueChanged(sender As Object, e As EventArgs) Handles UpDnServerPort.ValueChanged
        ComparePorts()
    End Sub

    Private Sub BtnDeleteLogo_Click(sender As Object, e As EventArgs) Handles BtnDeleteLogo.Click
        LblLogoFile.Text = ""
    End Sub

    Private Sub BtnSelectLogo_Click(sender As Object, e As EventArgs) Handles BtnSelectLogo.Click
        Dim oFile As New OpenFileDialog

        Try
            With oFile
                .Multiselect = False
                .Title = "Select splash screen logo file"
                .InitialDirectory = Application.StartupPath
                .ShowDialog()
                If Len(.FileName) Then LblLogoFile.Text = .FileName
            End With
        Catch ex As Exception

        End Try

    End Sub
End Class
