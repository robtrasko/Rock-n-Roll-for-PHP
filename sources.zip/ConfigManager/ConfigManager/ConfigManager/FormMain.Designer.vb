﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblSaved = New System.Windows.Forms.Label()
        Me.LblNonAdminMode = New System.Windows.Forms.Label()
        Me.BtnStopService = New System.Windows.Forms.Button()
        Me.BtnRunService = New System.Windows.Forms.Button()
        Me.BtnUninstallService = New System.Windows.Forms.Button()
        Me.BtnInstallService = New System.Windows.Forms.Button()
        Me.TxtServiceName = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ChkServerAsService = New System.Windows.Forms.CheckBox()
        Me.BtnLogDirectory = New System.Windows.Forms.Button()
        Me.ChkLogs = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.UpDnServerPort = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CboServerInterface = New System.Windows.Forms.ComboBox()
        Me.lblLogDirectory = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BtnMyAppDirectory = New System.Windows.Forms.Button()
        Me.BtnPHPDirectory = New System.Windows.Forms.Button()
        Me.lblPHPApplicationDirectory = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblPHPExeDirectory = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GrpInternalWebBrowser = New System.Windows.Forms.GroupBox()
        Me.BtnDeleteLogo = New System.Windows.Forms.Button()
        Me.BtnSelectLogo = New System.Windows.Forms.Button()
        Me.LblLogoFile = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TxtApplicationTitle = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.UpDownIB_Height = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.UpDownIB_Width = New System.Windows.Forms.NumericUpDown()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.UpDownIB_Top = New System.Windows.Forms.NumericUpDown()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.UpDownIB_Left = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.ChkResizableIB = New System.Windows.Forms.CheckBox()
        Me.ChkStartMaximizedIB = New System.Windows.Forms.CheckBox()
        Me.GrpCustomIE = New System.Windows.Forms.GroupBox()
        Me.ChkStatusBarIE = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.UpDnIE_Height = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.UpDnIE_Width = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.UpDnIE_Top = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.UpDnIE_Left = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ChkResizableIE = New System.Windows.Forms.CheckBox()
        Me.ChkToolBarIE = New System.Windows.Forms.CheckBox()
        Me.ChkMenuBarIE = New System.Windows.Forms.CheckBox()
        Me.ChkAddressBarIE = New System.Windows.Forms.CheckBox()
        Me.UpDnNawigate2Port = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.ChkStartWithConsole = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtNavigate2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TxtStartOptions = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CboWebBrowser = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ChkStartWithInternalWebServer = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.UpDnServerPort, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GrpInternalWebBrowser.SuspendLayout()
        CType(Me.UpDownIB_Height, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDownIB_Width, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDownIB_Top, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDownIB_Left, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GrpCustomIE.SuspendLayout()
        CType(Me.UpDnIE_Height, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDnIE_Width, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDnIE_Top, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDnIE_Left, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UpDnNawigate2Port, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(713, 37)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(119, 37)
        Me.btnSave.TabIndex = 2
        Me.btnSave.Text = "Save and  exit"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(715, 90)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(119, 36)
        Me.btnCancel.TabIndex = 3
        Me.btnCancel.Text = "Exit"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BtnLogDirectory)
        Me.GroupBox1.Controls.Add(Me.ChkLogs)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.UpDnServerPort)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.CboServerInterface)
        Me.GroupBox1.Controls.Add(Me.lblLogDirectory)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.BtnMyAppDirectory)
        Me.GroupBox1.Controls.Add(Me.BtnPHPDirectory)
        Me.GroupBox1.Controls.Add(Me.lblPHPApplicationDirectory)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.lblPHPExeDirectory)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 113)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(681, 132)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Server"
        '
        'lblSaved
        '
        Me.lblSaved.BackColor = System.Drawing.Color.LightGreen
        Me.lblSaved.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblSaved.Location = New System.Drawing.Point(481, 32)
        Me.lblSaved.Name = "lblSaved"
        Me.lblSaved.Size = New System.Drawing.Size(199, 68)
        Me.lblSaved.TabIndex = 53
        Me.lblSaved.Text = "Saved"
        Me.lblSaved.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblSaved.Visible = False
        '
        'LblNonAdminMode
        '
        Me.LblNonAdminMode.BackColor = System.Drawing.Color.Linen
        Me.LblNonAdminMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.LblNonAdminMode.Location = New System.Drawing.Point(25, 35)
        Me.LblNonAdminMode.Name = "LblNonAdminMode"
        Me.LblNonAdminMode.Size = New System.Drawing.Size(651, 25)
        Me.LblNonAdminMode.TabIndex = 52
        Me.LblNonAdminMode.Text = "To manage Windows services run 'Config Manager' as an Administrator"
        Me.LblNonAdminMode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LblNonAdminMode.Visible = False
        '
        'BtnStopService
        '
        Me.BtnStopService.Enabled = False
        Me.BtnStopService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnStopService.Location = New System.Drawing.Point(481, 35)
        Me.BtnStopService.Name = "BtnStopService"
        Me.BtnStopService.Size = New System.Drawing.Size(131, 25)
        Me.BtnStopService.TabIndex = 49
        Me.BtnStopService.Text = "Stop service"
        Me.BtnStopService.UseVisualStyleBackColor = True
        '
        'BtnRunService
        '
        Me.BtnRunService.Enabled = False
        Me.BtnRunService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnRunService.Location = New System.Drawing.Point(344, 35)
        Me.BtnRunService.Name = "BtnRunService"
        Me.BtnRunService.Size = New System.Drawing.Size(131, 25)
        Me.BtnRunService.TabIndex = 48
        Me.BtnRunService.Text = "Run service"
        Me.BtnRunService.UseVisualStyleBackColor = True
        '
        'BtnUninstallService
        '
        Me.BtnUninstallService.Enabled = False
        Me.BtnUninstallService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnUninstallService.Location = New System.Drawing.Point(207, 35)
        Me.BtnUninstallService.Name = "BtnUninstallService"
        Me.BtnUninstallService.Size = New System.Drawing.Size(131, 25)
        Me.BtnUninstallService.TabIndex = 47
        Me.BtnUninstallService.Text = "Uninstall service"
        Me.BtnUninstallService.UseVisualStyleBackColor = True
        '
        'BtnInstallService
        '
        Me.BtnInstallService.Enabled = False
        Me.BtnInstallService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnInstallService.Location = New System.Drawing.Point(70, 35)
        Me.BtnInstallService.Name = "BtnInstallService"
        Me.BtnInstallService.Size = New System.Drawing.Size(131, 25)
        Me.BtnInstallService.TabIndex = 46
        Me.BtnInstallService.Text = "Install service"
        Me.BtnInstallService.UseVisualStyleBackColor = True
        '
        'TxtServiceName
        '
        Me.TxtServiceName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtServiceName.Enabled = False
        Me.TxtServiceName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.TxtServiceName.Location = New System.Drawing.Point(375, 9)
        Me.TxtServiceName.Name = "TxtServiceName"
        Me.TxtServiceName.ReadOnly = True
        Me.TxtServiceName.Size = New System.Drawing.Size(304, 20)
        Me.TxtServiceName.TabIndex = 45
        Me.TxtServiceName.Text = "Rock'n'Roll Server"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label7.Location = New System.Drawing.Point(273, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 16)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Service name:"
        '
        'ChkServerAsService
        '
        Me.ChkServerAsService.AutoSize = True
        Me.ChkServerAsService.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkServerAsService.Location = New System.Drawing.Point(20, 12)
        Me.ChkServerAsService.Name = "ChkServerAsService"
        Me.ChkServerAsService.Size = New System.Drawing.Size(185, 17)
        Me.ChkServerAsService.TabIndex = 43
        Me.ChkServerAsService.Text = "Run server as a Windows service"
        Me.ChkServerAsService.UseVisualStyleBackColor = True
        '
        'BtnLogDirectory
        '
        Me.BtnLogDirectory.Enabled = False
        Me.BtnLogDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnLogDirectory.Location = New System.Drawing.Point(634, 100)
        Me.BtnLogDirectory.Name = "BtnLogDirectory"
        Me.BtnLogDirectory.Size = New System.Drawing.Size(34, 24)
        Me.BtnLogDirectory.TabIndex = 42
        Me.BtnLogDirectory.Text = "..."
        Me.BtnLogDirectory.UseVisualStyleBackColor = True
        '
        'ChkLogs
        '
        Me.ChkLogs.AutoSize = True
        Me.ChkLogs.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkLogs.Location = New System.Drawing.Point(8, 103)
        Me.ChkLogs.Name = "ChkLogs"
        Me.ChkLogs.Size = New System.Drawing.Size(83, 17)
        Me.ChkLogs.TabIndex = 41
        Me.ChkLogs.Text = "Save log to:"
        Me.ChkLogs.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label6.Location = New System.Drawing.Point(563, 80)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 13)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "8000 - default port"
        '
        'UpDnServerPort
        '
        Me.UpDnServerPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UpDnServerPort.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnServerPort.Location = New System.Drawing.Point(482, 78)
        Me.UpDnServerPort.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.UpDnServerPort.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.UpDnServerPort.Name = "UpDnServerPort"
        Me.UpDnServerPort.Size = New System.Drawing.Size(75, 20)
        Me.UpDnServerPort.TabIndex = 39
        Me.UpDnServerPort.ThousandsSeparator = True
        Me.UpDnServerPort.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label5.Location = New System.Drawing.Point(416, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 18)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Server port:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label4.Location = New System.Drawing.Point(245, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(153, 13)
        Me.Label4.TabIndex = 37
        Me.Label4.Text = "0.0.0.0  - listen on all interfaces"
        '
        'CboServerInterface
        '
        Me.CboServerInterface.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.CboServerInterface.FormattingEnabled = True
        Me.CboServerInterface.Items.AddRange(New Object() {"0.0.0.0", "localhost"})
        Me.CboServerInterface.Location = New System.Drawing.Point(139, 75)
        Me.CboServerInterface.Name = "CboServerInterface"
        Me.CboServerInterface.Size = New System.Drawing.Size(100, 21)
        Me.CboServerInterface.TabIndex = 36
        '
        'lblLogDirectory
        '
        Me.lblLogDirectory.BackColor = System.Drawing.SystemColors.Window
        Me.lblLogDirectory.Enabled = False
        Me.lblLogDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblLogDirectory.Location = New System.Drawing.Point(138, 104)
        Me.lblLogDirectory.Name = "lblLogDirectory"
        Me.lblLogDirectory.Size = New System.Drawing.Size(490, 18)
        Me.lblLogDirectory.TabIndex = 35
        Me.lblLogDirectory.Text = "xxx"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(127, 16)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Server interface:"
        '
        'BtnMyAppDirectory
        '
        Me.BtnMyAppDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnMyAppDirectory.Location = New System.Drawing.Point(634, 48)
        Me.BtnMyAppDirectory.Name = "BtnMyAppDirectory"
        Me.BtnMyAppDirectory.Size = New System.Drawing.Size(34, 22)
        Me.BtnMyAppDirectory.TabIndex = 33
        Me.BtnMyAppDirectory.Text = "..."
        Me.BtnMyAppDirectory.UseVisualStyleBackColor = True
        '
        'BtnPHPDirectory
        '
        Me.BtnPHPDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnPHPDirectory.Location = New System.Drawing.Point(634, 23)
        Me.BtnPHPDirectory.Name = "BtnPHPDirectory"
        Me.BtnPHPDirectory.Size = New System.Drawing.Size(34, 22)
        Me.BtnPHPDirectory.TabIndex = 32
        Me.BtnPHPDirectory.Text = "..."
        Me.BtnPHPDirectory.UseVisualStyleBackColor = True
        '
        'lblPHPApplicationDirectory
        '
        Me.lblPHPApplicationDirectory.BackColor = System.Drawing.SystemColors.Window
        Me.lblPHPApplicationDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblPHPApplicationDirectory.Location = New System.Drawing.Point(139, 52)
        Me.lblPHPApplicationDirectory.Name = "lblPHPApplicationDirectory"
        Me.lblPHPApplicationDirectory.Size = New System.Drawing.Size(490, 18)
        Me.lblPHPApplicationDirectory.TabIndex = 31
        Me.lblPHPApplicationDirectory.Text = "xxx"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 52)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(127, 16)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "My application directory:"
        '
        'lblPHPExeDirectory
        '
        Me.lblPHPExeDirectory.BackColor = System.Drawing.SystemColors.Window
        Me.lblPHPExeDirectory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblPHPExeDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.lblPHPExeDirectory.Location = New System.Drawing.Point(139, 25)
        Me.lblPHPExeDirectory.Name = "lblPHPExeDirectory"
        Me.lblPHPExeDirectory.Size = New System.Drawing.Size(490, 18)
        Me.lblPHPExeDirectory.TabIndex = 29
        Me.lblPHPExeDirectory.Text = "xxx"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 16)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "PHP root directory:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.GrpInternalWebBrowser)
        Me.GroupBox2.Controls.Add(Me.GrpCustomIE)
        Me.GroupBox2.Controls.Add(Me.UpDnNawigate2Port)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.Panel1)
        Me.GroupBox2.Controls.Add(Me.TxtNavigate2)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.TxtStartOptions)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.CboWebBrowser)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 261)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(681, 266)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Browser"
        '
        'GrpInternalWebBrowser
        '
        Me.GrpInternalWebBrowser.Controls.Add(Me.BtnDeleteLogo)
        Me.GrpInternalWebBrowser.Controls.Add(Me.BtnSelectLogo)
        Me.GrpInternalWebBrowser.Controls.Add(Me.LblLogoFile)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label26)
        Me.GrpInternalWebBrowser.Controls.Add(Me.TxtApplicationTitle)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label21)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label16)
        Me.GrpInternalWebBrowser.Controls.Add(Me.UpDownIB_Height)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label17)
        Me.GrpInternalWebBrowser.Controls.Add(Me.UpDownIB_Width)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label18)
        Me.GrpInternalWebBrowser.Controls.Add(Me.UpDownIB_Top)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label19)
        Me.GrpInternalWebBrowser.Controls.Add(Me.UpDownIB_Left)
        Me.GrpInternalWebBrowser.Controls.Add(Me.Label20)
        Me.GrpInternalWebBrowser.Controls.Add(Me.ChkResizableIB)
        Me.GrpInternalWebBrowser.Controls.Add(Me.ChkStartMaximizedIB)
        Me.GrpInternalWebBrowser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.GrpInternalWebBrowser.Location = New System.Drawing.Point(26, 101)
        Me.GrpInternalWebBrowser.Name = "GrpInternalWebBrowser"
        Me.GrpInternalWebBrowser.Size = New System.Drawing.Size(638, 151)
        Me.GrpInternalWebBrowser.TabIndex = 35
        Me.GrpInternalWebBrowser.TabStop = False
        Me.GrpInternalWebBrowser.Text = "Internal web browser options"
        Me.GrpInternalWebBrowser.Visible = False
        '
        'BtnDeleteLogo
        '
        Me.BtnDeleteLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnDeleteLogo.Location = New System.Drawing.Point(613, 112)
        Me.BtnDeleteLogo.Name = "BtnDeleteLogo"
        Me.BtnDeleteLogo.Size = New System.Drawing.Size(19, 24)
        Me.BtnDeleteLogo.TabIndex = 44
        Me.BtnDeleteLogo.Text = "X"
        Me.BtnDeleteLogo.UseVisualStyleBackColor = True
        '
        'BtnSelectLogo
        '
        Me.BtnSelectLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.BtnSelectLogo.Location = New System.Drawing.Point(585, 112)
        Me.BtnSelectLogo.Name = "BtnSelectLogo"
        Me.BtnSelectLogo.Size = New System.Drawing.Size(29, 24)
        Me.BtnSelectLogo.TabIndex = 43
        Me.BtnSelectLogo.Text = "..."
        Me.BtnSelectLogo.UseVisualStyleBackColor = True
        '
        'LblLogoFile
        '
        Me.LblLogoFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.LblLogoFile.Location = New System.Drawing.Point(304, 118)
        Me.LblLogoFile.Name = "LblLogoFile"
        Me.LblLogoFile.Size = New System.Drawing.Size(275, 27)
        Me.LblLogoFile.TabIndex = 28
        Me.LblLogoFile.Text = "."
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label26.Location = New System.Drawing.Point(200, 118)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(97, 13)
        Me.Label26.TabIndex = 27
        Me.Label26.Text = "Splash screen logo"
        '
        'TxtApplicationTitle
        '
        Me.TxtApplicationTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtApplicationTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.TxtApplicationTitle.Location = New System.Drawing.Point(307, 48)
        Me.TxtApplicationTitle.Name = "TxtApplicationTitle"
        Me.TxtApplicationTitle.Size = New System.Drawing.Size(324, 20)
        Me.TxtApplicationTitle.TabIndex = 26
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label21.Location = New System.Drawing.Point(200, 51)
        Me.Label21.Margin = New System.Windows.Forms.Padding(0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(81, 13)
        Me.Label21.TabIndex = 25
        Me.Label21.Text = "Application title:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label16.Location = New System.Drawing.Point(23, 127)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 13)
        Me.Label16.TabIndex = 23
        Me.Label16.Text = "Height:"
        '
        'UpDownIB_Height
        '
        Me.UpDownIB_Height.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDownIB_Height.Location = New System.Drawing.Point(94, 125)
        Me.UpDownIB_Height.Maximum = New Decimal(New Integer() {1800, 0, 0, 0})
        Me.UpDownIB_Height.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDownIB_Height.Name = "UpDownIB_Height"
        Me.UpDownIB_Height.Size = New System.Drawing.Size(56, 20)
        Me.UpDownIB_Height.TabIndex = 24
        Me.UpDownIB_Height.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label17.Location = New System.Drawing.Point(23, 101)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Width:"
        '
        'UpDownIB_Width
        '
        Me.UpDownIB_Width.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDownIB_Width.Location = New System.Drawing.Point(94, 99)
        Me.UpDownIB_Width.Maximum = New Decimal(New Integer() {3000, 0, 0, 0})
        Me.UpDownIB_Width.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDownIB_Width.Name = "UpDownIB_Width"
        Me.UpDownIB_Width.Size = New System.Drawing.Size(56, 20)
        Me.UpDownIB_Width.TabIndex = 22
        Me.UpDownIB_Width.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label18.Location = New System.Drawing.Point(23, 75)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(29, 13)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "Top:"
        '
        'UpDownIB_Top
        '
        Me.UpDownIB_Top.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDownIB_Top.Location = New System.Drawing.Point(94, 73)
        Me.UpDownIB_Top.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.UpDownIB_Top.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDownIB_Top.Name = "UpDownIB_Top"
        Me.UpDownIB_Top.Size = New System.Drawing.Size(56, 20)
        Me.UpDownIB_Top.TabIndex = 20
        Me.UpDownIB_Top.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label19.Location = New System.Drawing.Point(23, 49)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 13)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "Left:"
        '
        'UpDownIB_Left
        '
        Me.UpDownIB_Left.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDownIB_Left.Location = New System.Drawing.Point(94, 47)
        Me.UpDownIB_Left.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.UpDownIB_Left.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDownIB_Left.Name = "UpDownIB_Left"
        Me.UpDownIB_Left.Size = New System.Drawing.Size(56, 20)
        Me.UpDownIB_Left.TabIndex = 18
        Me.UpDownIB_Left.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label20.Location = New System.Drawing.Point(21, 23)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(311, 13)
        Me.Label20.TabIndex = 17
        Me.Label20.Text = "Position when browser starts (value {-1} means: use last position)"
        '
        'ChkResizableIB
        '
        Me.ChkResizableIB.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChkResizableIB.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkResizableIB.Location = New System.Drawing.Point(198, 96)
        Me.ChkResizableIB.Name = "ChkResizableIB"
        Me.ChkResizableIB.Size = New System.Drawing.Size(123, 18)
        Me.ChkResizableIB.TabIndex = 3
        Me.ChkResizableIB.Text = "Resizable"
        Me.ChkResizableIB.UseVisualStyleBackColor = True
        '
        'ChkStartMaximizedIB
        '
        Me.ChkStartMaximizedIB.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ChkStartMaximizedIB.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkStartMaximizedIB.Location = New System.Drawing.Point(198, 74)
        Me.ChkStartMaximizedIB.Name = "ChkStartMaximizedIB"
        Me.ChkStartMaximizedIB.Size = New System.Drawing.Size(123, 17)
        Me.ChkStartMaximizedIB.TabIndex = 2
        Me.ChkStartMaximizedIB.Text = "Start maximized"
        Me.ChkStartMaximizedIB.UseVisualStyleBackColor = True
        '
        'GrpCustomIE
        '
        Me.GrpCustomIE.Controls.Add(Me.ChkStatusBarIE)
        Me.GrpCustomIE.Controls.Add(Me.Label15)
        Me.GrpCustomIE.Controls.Add(Me.UpDnIE_Height)
        Me.GrpCustomIE.Controls.Add(Me.Label14)
        Me.GrpCustomIE.Controls.Add(Me.UpDnIE_Width)
        Me.GrpCustomIE.Controls.Add(Me.Label13)
        Me.GrpCustomIE.Controls.Add(Me.UpDnIE_Top)
        Me.GrpCustomIE.Controls.Add(Me.Label12)
        Me.GrpCustomIE.Controls.Add(Me.UpDnIE_Left)
        Me.GrpCustomIE.Controls.Add(Me.Label11)
        Me.GrpCustomIE.Controls.Add(Me.ChkResizableIE)
        Me.GrpCustomIE.Controls.Add(Me.ChkToolBarIE)
        Me.GrpCustomIE.Controls.Add(Me.ChkMenuBarIE)
        Me.GrpCustomIE.Controls.Add(Me.ChkAddressBarIE)
        Me.GrpCustomIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.GrpCustomIE.Location = New System.Drawing.Point(26, 101)
        Me.GrpCustomIE.Name = "GrpCustomIE"
        Me.GrpCustomIE.Size = New System.Drawing.Size(612, 161)
        Me.GrpCustomIE.TabIndex = 34
        Me.GrpCustomIE.TabStop = False
        Me.GrpCustomIE.Text = "Customized IE"
        Me.GrpCustomIE.Visible = False
        '
        'ChkStatusBarIE
        '
        Me.ChkStatusBarIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkStatusBarIE.Location = New System.Drawing.Point(401, 110)
        Me.ChkStatusBarIE.Name = "ChkStatusBarIE"
        Me.ChkStatusBarIE.Size = New System.Drawing.Size(151, 17)
        Me.ChkStatusBarIE.TabIndex = 25
        Me.ChkStatusBarIE.Text = "Display status bar"
        Me.ChkStatusBarIE.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label15.Location = New System.Drawing.Point(16, 126)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 13)
        Me.Label15.TabIndex = 23
        Me.Label15.Text = "Height:"
        '
        'UpDnIE_Height
        '
        Me.UpDnIE_Height.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnIE_Height.Location = New System.Drawing.Point(87, 124)
        Me.UpDnIE_Height.Maximum = New Decimal(New Integer() {1800, 0, 0, 0})
        Me.UpDnIE_Height.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDnIE_Height.Name = "UpDnIE_Height"
        Me.UpDnIE_Height.Size = New System.Drawing.Size(56, 20)
        Me.UpDnIE_Height.TabIndex = 24
        Me.UpDnIE_Height.Value = New Decimal(New Integer() {500, 0, 0, 0})
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label14.Location = New System.Drawing.Point(16, 100)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(38, 13)
        Me.Label14.TabIndex = 21
        Me.Label14.Text = "Width:"
        '
        'UpDnIE_Width
        '
        Me.UpDnIE_Width.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnIE_Width.Location = New System.Drawing.Point(87, 98)
        Me.UpDnIE_Width.Maximum = New Decimal(New Integer() {3000, 0, 0, 0})
        Me.UpDnIE_Width.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDnIE_Width.Name = "UpDnIE_Width"
        Me.UpDnIE_Width.Size = New System.Drawing.Size(56, 20)
        Me.UpDnIE_Width.TabIndex = 22
        Me.UpDnIE_Width.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label13.Location = New System.Drawing.Point(16, 74)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(29, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Top:"
        '
        'UpDnIE_Top
        '
        Me.UpDnIE_Top.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnIE_Top.Location = New System.Drawing.Point(87, 72)
        Me.UpDnIE_Top.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.UpDnIE_Top.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDnIE_Top.Name = "UpDnIE_Top"
        Me.UpDnIE_Top.Size = New System.Drawing.Size(56, 20)
        Me.UpDnIE_Top.TabIndex = 20
        Me.UpDnIE_Top.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label12.Location = New System.Drawing.Point(16, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 13)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Left:"
        '
        'UpDnIE_Left
        '
        Me.UpDnIE_Left.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnIE_Left.Location = New System.Drawing.Point(87, 46)
        Me.UpDnIE_Left.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.UpDnIE_Left.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.UpDnIE_Left.Name = "UpDnIE_Left"
        Me.UpDnIE_Left.Size = New System.Drawing.Size(56, 20)
        Me.UpDnIE_Left.TabIndex = 18
        Me.UpDnIE_Left.Value = New Decimal(New Integer() {300, 0, 0, 0})
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label11.Location = New System.Drawing.Point(16, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(311, 13)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Position when browser starts (value {-1} means: use last position)"
        '
        'ChkResizableIE
        '
        Me.ChkResizableIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkResizableIE.Location = New System.Drawing.Point(401, 130)
        Me.ChkResizableIE.Name = "ChkResizableIE"
        Me.ChkResizableIE.Size = New System.Drawing.Size(151, 18)
        Me.ChkResizableIE.TabIndex = 3
        Me.ChkResizableIE.Text = "Resizable"
        Me.ChkResizableIE.UseVisualStyleBackColor = True
        '
        'ChkToolBarIE
        '
        Me.ChkToolBarIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkToolBarIE.Location = New System.Drawing.Point(401, 91)
        Me.ChkToolBarIE.Name = "ChkToolBarIE"
        Me.ChkToolBarIE.Size = New System.Drawing.Size(151, 17)
        Me.ChkToolBarIE.TabIndex = 2
        Me.ChkToolBarIE.Text = "Display tool bar"
        Me.ChkToolBarIE.UseVisualStyleBackColor = True
        '
        'ChkMenuBarIE
        '
        Me.ChkMenuBarIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkMenuBarIE.Location = New System.Drawing.Point(401, 70)
        Me.ChkMenuBarIE.Name = "ChkMenuBarIE"
        Me.ChkMenuBarIE.Size = New System.Drawing.Size(151, 17)
        Me.ChkMenuBarIE.TabIndex = 1
        Me.ChkMenuBarIE.Text = "Display menu bar"
        Me.ChkMenuBarIE.UseVisualStyleBackColor = True
        '
        'ChkAddressBarIE
        '
        Me.ChkAddressBarIE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkAddressBarIE.Location = New System.Drawing.Point(401, 48)
        Me.ChkAddressBarIE.Name = "ChkAddressBarIE"
        Me.ChkAddressBarIE.Size = New System.Drawing.Size(151, 20)
        Me.ChkAddressBarIE.TabIndex = 0
        Me.ChkAddressBarIE.Text = "Display address bar"
        Me.ChkAddressBarIE.UseVisualStyleBackColor = True
        '
        'UpDnNawigate2Port
        '
        Me.UpDnNawigate2Port.BackColor = System.Drawing.SystemColors.Window
        Me.UpDnNawigate2Port.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UpDnNawigate2Port.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.UpDnNawigate2Port.Location = New System.Drawing.Point(589, 71)
        Me.UpDnNawigate2Port.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.UpDnNawigate2Port.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.UpDnNawigate2Port.Name = "UpDnNawigate2Port"
        Me.UpDnNawigate2Port.Size = New System.Drawing.Size(75, 20)
        Me.UpDnNawigate2Port.TabIndex = 40
        Me.UpDnNawigate2Port.ThousandsSeparator = True
        Me.UpDnNawigate2Port.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label25.Location = New System.Drawing.Point(510, 71)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(73, 17)
        Me.Label25.TabIndex = 39
        Me.Label25.Text = "Port:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ChkStartWithConsole
        '
        Me.ChkStartWithConsole.AutoSize = True
        Me.ChkStartWithConsole.Enabled = False
        Me.ChkStartWithConsole.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkStartWithConsole.Location = New System.Drawing.Point(46, 90)
        Me.ChkStartWithConsole.Name = "ChkStartWithConsole"
        Me.ChkStartWithConsole.Size = New System.Drawing.Size(200, 17)
        Me.ChkStartWithConsole.TabIndex = 35
        Me.ChkStartWithConsole.Text = "Start built-in PHP server with console"
        Me.ChkStartWithConsole.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Location = New System.Drawing.Point(16, 101)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(652, 118)
        Me.Panel1.TabIndex = 34
        '
        'Label24
        '
        Me.Label24.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label24.Location = New System.Drawing.Point(0, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(652, 118)
        Me.Label24.TabIndex = 36
        Me.Label24.Text = "System default browser can be used with <Run server as a Windows service> enabled" &
    ""
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TxtNavigate2
        '
        Me.TxtNavigate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtNavigate2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.TxtNavigate2.Location = New System.Drawing.Point(224, 70)
        Me.TxtNavigate2.Name = "TxtNavigate2"
        Me.TxtNavigate2.Size = New System.Drawing.Size(264, 20)
        Me.TxtNavigate2.TabIndex = 33
        Me.TxtNavigate2.Text = "http://localhost"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label10.Location = New System.Drawing.Point(14, 73)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(118, 13)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "When start navigate to:"
        '
        'TxtStartOptions
        '
        Me.TxtStartOptions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtStartOptions.Enabled = False
        Me.TxtStartOptions.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.TxtStartOptions.Location = New System.Drawing.Point(224, 46)
        Me.TxtStartOptions.Name = "TxtStartOptions"
        Me.TxtStartOptions.Size = New System.Drawing.Size(441, 20)
        Me.TxtStartOptions.TabIndex = 31
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label9.Location = New System.Drawing.Point(14, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(137, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Web browser start switches"
        '
        'CboWebBrowser
        '
        Me.CboWebBrowser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CboWebBrowser.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.CboWebBrowser.FormattingEnabled = True
        Me.CboWebBrowser.Items.AddRange(New Object() {"Built-in internal web browser", "Customized Internet Explorer", "System default"})
        Me.CboWebBrowser.Location = New System.Drawing.Point(224, 21)
        Me.CboWebBrowser.Name = "CboWebBrowser"
        Me.CboWebBrowser.Size = New System.Drawing.Size(440, 21)
        Me.CboWebBrowser.TabIndex = 29
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label8.Location = New System.Drawing.Point(14, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(174, 13)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "What web browser you want to use"
        '
        'ChkStartWithInternalWebServer
        '
        Me.ChkStartWithInternalWebServer.AutoSize = True
        Me.ChkStartWithInternalWebServer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ChkStartWithInternalWebServer.Location = New System.Drawing.Point(21, 66)
        Me.ChkStartWithInternalWebServer.Name = "ChkStartWithInternalWebServer"
        Me.ChkStartWithInternalWebServer.Size = New System.Drawing.Size(198, 17)
        Me.ChkStartWithInternalWebServer.TabIndex = 27
        Me.ChkStartWithInternalWebServer.Text = "Start browser with built-in web server"
        Me.ChkStartWithInternalWebServer.UseVisualStyleBackColor = True
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(859, 538)
        Me.Controls.Add(Me.lblSaved)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.LblNonAdminMode)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.ChkStartWithConsole)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtnStopService)
        Me.Controls.Add(Me.ChkServerAsService)
        Me.Controls.Add(Me.BtnRunService)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.BtnUninstallService)
        Me.Controls.Add(Me.TxtServiceName)
        Me.Controls.Add(Me.ChkStartWithInternalWebServer)
        Me.Controls.Add(Me.BtnInstallService)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormMain"
        Me.Text = "Rock'n'Roll Config Manager"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.UpDnServerPort, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GrpInternalWebBrowser.ResumeLayout(False)
        Me.GrpInternalWebBrowser.PerformLayout()
        CType(Me.UpDownIB_Height, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDownIB_Width, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDownIB_Top, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDownIB_Left, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GrpCustomIE.ResumeLayout(False)
        Me.GrpCustomIE.PerformLayout()
        CType(Me.UpDnIE_Height, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDnIE_Width, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDnIE_Top, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDnIE_Left, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UpDnNawigate2Port, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSave As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BtnStopService As Button
    Friend WithEvents BtnRunService As Button
    Friend WithEvents BtnUninstallService As Button
    Friend WithEvents BtnInstallService As Button
    Friend WithEvents TxtServiceName As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ChkServerAsService As CheckBox
    Friend WithEvents BtnLogDirectory As Button
    Friend WithEvents ChkLogs As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents UpDnServerPort As NumericUpDown
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CboServerInterface As ComboBox
    Friend WithEvents lblLogDirectory As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnMyAppDirectory As Button
    Friend WithEvents BtnPHPDirectory As Button
    Friend WithEvents lblPHPApplicationDirectory As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblPHPExeDirectory As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GrpInternalWebBrowser As GroupBox
    Friend WithEvents TxtApplicationTitle As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents UpDownIB_Height As NumericUpDown
    Friend WithEvents Label17 As Label
    Friend WithEvents UpDownIB_Width As NumericUpDown
    Friend WithEvents Label18 As Label
    Friend WithEvents UpDownIB_Top As NumericUpDown
    Friend WithEvents Label19 As Label
    Friend WithEvents UpDownIB_Left As NumericUpDown
    Friend WithEvents Label20 As Label
    Friend WithEvents ChkResizableIB As CheckBox
    Friend WithEvents ChkStartMaximizedIB As CheckBox
    Friend WithEvents GrpCustomIE As GroupBox
    Friend WithEvents Label15 As Label
    Friend WithEvents UpDnIE_Height As NumericUpDown
    Friend WithEvents Label14 As Label
    Friend WithEvents UpDnIE_Width As NumericUpDown
    Friend WithEvents Label13 As Label
    Friend WithEvents UpDnIE_Top As NumericUpDown
    Friend WithEvents Label12 As Label
    Friend WithEvents UpDnIE_Left As NumericUpDown
    Friend WithEvents Label11 As Label
    Friend WithEvents ChkResizableIE As CheckBox
    Friend WithEvents ChkToolBarIE As CheckBox
    Friend WithEvents ChkMenuBarIE As CheckBox
    Friend WithEvents ChkAddressBarIE As CheckBox
    Friend WithEvents TxtNavigate2 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TxtStartOptions As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CboWebBrowser As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ChkStartWithInternalWebServer As CheckBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ChkStartWithConsole As CheckBox
    Friend WithEvents Label24 As Label
    Friend WithEvents LblNonAdminMode As Label
    Friend WithEvents UpDnNawigate2Port As NumericUpDown
    Friend WithEvents Label25 As Label
    Friend WithEvents ChkStatusBarIE As CheckBox
    Friend WithEvents BtnDeleteLogo As Button
    Friend WithEvents BtnSelectLogo As Button
    Friend WithEvents LblLogoFile As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents lblSaved As Label
End Class
