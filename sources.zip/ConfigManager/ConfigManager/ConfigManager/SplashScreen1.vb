﻿Public NotInheritable Class SplashScreen1

    'TODO: Ten formularz może być łatwo ustawiony jako ekran powitalny dla aplikacji przez przejście do karty „Aplikacja”
    '  Projektanta projektu („Właściwości” w menu „Projekt”).


    Private Sub SplashScreen1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor)

        'Informacje o prawach autorskich
        Copyright.Text = My.Application.Info.Copyright
    End Sub

End Class
