﻿Imports System.ComponentModel
Imports System.Linq
Imports Microsoft.Win32

Public Class emBrowser

    Private WithEvents ProcBrowser As New Process
    Private WithEvents ProcServer As New Process
    'Private WithEvents BgWorker As BackgroundWorker
    Private RnR As New Rock_n_Roll_Commons

    Declare Auto Function SetParent Lib "user32.dll" (ByVal hWndChild As IntPtr, ByVal hWndNewParent As IntPtr) As Integer
    Declare Auto Function SendMessage Lib "user32.dll" (ByVal hWnd As IntPtr, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Private Const WM_SYSCOMMAND As Integer = 274
    Private Const SC_MAXIMIZE As Integer = 61488
    Private Declare Auto Function GetWindowThreadProcessId Lib "user32.dll" (ByVal hwnd As IntPtr, ByRef lpdwProcessId As Integer) As Integer

    Private Sub emBrowser_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.WindowState = FormWindowState.Minimized
        Me.Visible = False
        Me.ShowInTaskbar = False
        If UCase(RnR.SettingFor("Browser")) = "BUILT-IN" Or UCase(RnR.SettingFor("Browser")) = "CUSTOMIZEDIE" Then
            If UCase(RnR.SettingFor("BrowserStartsWithBuiltInServer")) = "TRUE" And Process.GetProcessesByName("php").Count = 0 Then LaunchBuilInServer()
        End If

        Select Case UCase(RnR.SettingFor("Browser"))
            Case "BUILT-IN"
                LaunchBuiltInBrowser()
                Me.ShowInTaskbar = True
                Me.Show()
            Case "CUSTOMIZEDIE"
                LaunchCustomizedIE()

            Case "DEFAULT"
                LauchDefaultBrowser()
                End
            Case Else
                'if browser is not set then start system default browser
                LauchDefaultBrowser()
                End
        End Select

        TmrCheckProcesses.Enabled = True

    End Sub

    Private Sub LaunchBuiltInBrowser()
        Err.Clear()
        Try
            Me.Text = Trim(RnR.SettingFor("BuiltInMyBrowser_Title"))
            If Val(RnR.SettingFor("BuiltInMyBrowser_Left")) > 0 Then Me.Left = Val(RnR.SettingFor("BuiltInMyBrowser_Left"))
            If Val(RnR.SettingFor("BuiltInMyBrowser_Top")) > 0 Then Me.Top = Val(RnR.SettingFor("BuiltInMyBrowser_Top"))
            If Val(RnR.SettingFor("BuiltInMyBrowser_Width")) > 0 Then Me.Width = Val(RnR.SettingFor("BuiltInMyBrowser_Width"))
            If Val(RnR.SettingFor("BuiltInMyBrowser_Height")) > 0 Then Me.Height = Val(RnR.SettingFor("BuiltInMyBrowser_Height"))
            If UCase(RnR.SettingFor("BuiltInMyBrowser_Resizable")) = "TRUE" Then
                Me.MinimizeBox = False
                Me.MaximizeBox = False
            End If
            If UCase(RnR.SettingFor("BuiltInMyBrowser_StartMaximized")) = "TRUE" Then
                Me.WindowState = FormWindowState.Maximized
            Else
                Me.WindowState = FormWindowState.Normal
            End If

            Me.BrwBrowser.Navigate(RnR.SettingFor("BrowserNavigate2") & ":" & RnR.SettingFor("BrowserNavigate2Port"))

        Catch ex As Exception
            If Err.Number <> 0 Then
                If UCase(RnR.SettingFor("LogsEnabled")) = "TRUE" Then
                    RnR.SaveToLog(Err.Description)
                    MsgBox("Problem with launching internal browser. Check log file for details.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Internal browser")
                Else
                    MsgBox(Err.Description, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Internal browser")
                End If
                Err.Clear()
            End If
        End Try
    End Sub

    Private Sub LaunchCustomizedIE()
        Dim IE As Object
        Dim IEhwnd As Integer
        Dim iProcId As Integer = 0

        Err.Clear()
        Try
            IE = Interaction.CreateObject("InternetExplorer.Application")
            IEhwnd = IE.hwnd
            GetWindowThreadProcessId(IEhwnd, iProcId)
            ProcBrowser = Process.GetProcessById(iProcId)
            ProcBrowser.EnableRaisingEvents = True
            With IE
                .AddressBar = Convert.ToBoolean(RnR.SettingFor("CustomIE_AddressBar"))
                .MenuBar = Convert.ToBoolean(RnR.SettingFor("CustomIE_MenuBar"))
                .ToolBar = Convert.ToBoolean(RnR.SettingFor("CustomIE_ToolBar"))
                .StatusBar = Convert.ToBoolean(RnR.SettingFor("CustomIE_StatusBar"))
                '.StatusBar = False
                .Resizable = Convert.ToBoolean(RnR.SettingFor("CustomIE_Resizable"))
                If Val(RnR.SettingFor("CustomIE_Left")) > 0 Then .Left = Val(RnR.SettingFor("CustomIE_Left"))
                If Val(RnR.SettingFor("CustomIE_Top")) > 0 Then .Top = Val(RnR.SettingFor("CustomIE_Top"))
                If Val(RnR.SettingFor("CustomIE_Width")) > 0 Then .Width = Val(RnR.SettingFor("CustomIE_Width"))
                If Val(RnR.SettingFor("CustomIE_Height")) > 0 Then .Height = Val(RnR.SettingFor("CustomIE_Height"))
                .Visible = 1
                .Navigate(RnR.SettingFor("BrowserNavigate2") & ":" & RnR.SettingFor("BrowserNavigate2Port"))
            End With
            AppActivate(iProcId)
        Catch ex As Exception
            If Err.Number <> 0 Then
                If UCase(RnR.SettingFor("LogsEnabled")) = "TRUE" Then
                    RnR.SaveToLog(Err.Description)
                    MsgBox("Problem with launching customized Internet Explorer. Check log file for details.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Customized IE")
                Else
                    MsgBox(Err.Description, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Customized IE")
                End If
                Err.Clear()
            End If
        End Try

    End Sub

    Private Sub LauchDefaultBrowser()
        Dim iProcID As Integer = 0

        Err.Clear()
        Try
            With ProcBrowser.StartInfo
                .FileName = RnR.SettingFor("BrowserNavigate2") & ":" & RnR.SettingFor("ServerPort")
                .Arguments = RnR.SettingFor("BrowserStartOptions")
            End With
            ProcBrowser.Start()
            ProcBrowser.EnableRaisingEvents = True

        Catch ex As Exception
            If Err.Number <> 0 Then
                If UCase(RnR.SettingFor("LogsEnabled")) = "TRUE" Then
                    RnR.SaveToLog(Err.Description)
                    MsgBox("Problem with launching default web browser. Check log file for details.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Browser")
                Else
                    MsgBox(Err.Description, MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Browser")
                End If
                Err.Clear()
            End If
        End Try
    End Sub

    Private Sub LaunchBuilInServer()
        Dim ServerExe As String = RnR.SettingFor("PHPExecutableDirectory") & "\php.exe"
        Dim InitOptions As String = "-S " & RnR.SettingFor("ServerInterface") & ":" & RnR.SettingFor("ServerPort") & " -t " & RnR.SettingFor("PHPApplicationDirectory")
        Dim ErrText As String = ""

        If Not System.IO.File.Exists(ServerExe) Then ErrText = "The file " & ServerExe & " does not exist."
        If Not System.IO.File.Exists(RnR.SettingFor("PHPApplicationDirectory") & "\index.php") Then
            If Len(ErrText) Then ErrText = ErrText & vbCrLf
            ErrText = ErrText & "The file " & RnR.SettingFor("PHPApplicationDirectory") & "\index.php" & " does not exist."
        End If
        If Len(ErrText) = 0 Then
            Try
                With ProcServer.StartInfo
                    .FileName = ServerExe
                    .Arguments = InitOptions
                    .UseShellExecute = False
                    If UCase(RnR.SettingFor("BrowserStartsWithServerConsole")) = "TRUE" Then
                        .CreateNoWindow = False
                        .RedirectStandardInput = False
                        .RedirectStandardOutput = False
                        .RedirectStandardError = False
                    Else
                        .CreateNoWindow = True
                        .RedirectStandardInput = True
                        .RedirectStandardOutput = True
                        .RedirectStandardError = True
                    End If
                End With
                ProcServer.Start()
                If UCase(RnR.SettingFor("BrowserStartsWithServerConsole")) = "FALSE" Then
                    'if standard output has been redirected then raise console events 
                    ProcServer.BeginErrorReadLine()
                    ProcServer.BeginOutputReadLine()
                Else
                    Try
                        ProcServer.WaitForInputIdle()
                    Catch ex As Exception
                        Err.Clear()
                    End Try
                End If
                RnR.SaveToLog("Embeded server started.")
            Catch ex As Exception
                ErrText = "Can't start server process. " & Err.Description & vbCrLf & ServerExe
            End Try
        End If

        If Len(ErrText) > 0 Then
            'SplashScreen.SendToBack()
            If UCase(RnR.SettingFor("LogsEnabled")) = "TRUE" Then
                RnR.SaveToLog(ErrText)
                MsgBox("Can't launch embeded PHP server. Check log file for details.", MsgBoxStyle.Exclamation + MsgBoxStyle.ApplicationModal + MsgBoxStyle.OkOnly, "Embeded server")
            Else
                MsgBox(ErrText, MsgBoxStyle.Exclamation + MsgBoxStyle.ApplicationModal + MsgBoxStyle.OkOnly, "Embeded server")
            End If
            Err.Clear()
        End If
    End Sub

    Private Sub ProcServer_OutputDataReceived(sender As Object, e As DataReceivedEventArgs) Handles ProcServer.OutputDataReceived
        RnR.SaveToLog(e.Data)
    End Sub

    Private Sub ProcServer_ErrorDataReceived(sender As Object, e As DataReceivedEventArgs) Handles ProcServer.ErrorDataReceived
        RnR.SaveToLog(e.Data)
    End Sub

    Private Sub CloseAllProcesses()

        Try
            If ProcServer.Responding Then ProcServer.Kill()
            ProcServer.Close()
        Catch ex As Exception
            RnR.SaveToLog(Err.Description)
        End Try
        If UCase(RnR.SettingFor("Browser")) <> "BUILT-IN" Then
            Try
                If ProcBrowser.Responding Then ProcBrowser.Kill()
                ProcBrowser.Close()
            Catch ex As Exception
                RnR.SaveToLog(Err.Description)
            End Try
        End If

    End Sub

    Private Sub emBrowser_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        CloseAllProcesses()
    End Sub

    Private Sub emBrowser_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Try
            If UCase(RnR.SettingFor("Browser")) = "BUILT-IN" Then
                Me.Activate()
            Else
                Me.Hide()
                Me.ShowInTaskbar = False
                AppActivate(ProcBrowser.Id)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ProcBrowser_Exited(sender As Object, e As EventArgs) Handles ProcBrowser.Exited
        CloseAllProcesses()
        End
    End Sub

    Private Sub ProcBrowser_Disposed(sender As Object, e As EventArgs) Handles ProcBrowser.Disposed
        CloseAllProcesses()
        End
    End Sub

    Private Sub TmrCheckProcesses_Tick(sender As Object, e As EventArgs) Handles TmrCheckProcesses.Tick

        Try
            If Len(ProcServer.StartInfo.FileName) Then
                If Not ProcServer.Responding Then
                    CloseAllProcesses()
                    End
                End If
            End If
        Catch ex As Exception
            End
        End Try
    End Sub

End Class
