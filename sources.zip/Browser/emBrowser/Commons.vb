﻿Public Class Rock_n_Roll_Commons

    Private colConfig As New System.Collections.Generic.Dictionary(Of String, String)
    'Private colConfig As New Microsoft.VisualBasic.Collection

    Public Sub New()

        LoadConfig()

    End Sub
    Public Sub Clear()
        colConfig.Clear()
    End Sub

    Public Property SettingFor(sKey As String)

        Get
            Try
                SettingFor = colConfig(sKey)
            Catch ex As Exception
                SettingFor = ""
            End Try
        End Get

        Set(sValue)
            Try
                colConfig.Remove(sKey)
                colConfig.Add(sKey, sValue)
            Catch ex As Exception

            End Try
        End Set

    End Property

    Public Sub SaveSettings()

        Dim sLine As String = ""
        Dim flFileWriter As System.IO.StreamWriter
        Dim oPair As KeyValuePair(Of String, String)

        Err.Clear()
        Try
            If System.IO.File.Exists("RnRSettings.ini") Then System.IO.File.Delete("RnRSettings.ini")
            flFileWriter = IO.File.CreateText("RnRSettings.ini")
            flFileWriter.WriteLine("#======================================================#")
            flFileWriter.WriteLine("#       Configuration file for Rock_n_Roll tools       #")
            flFileWriter.WriteLine("#   this file has been created by RnR Config Manager   #")
            flFileWriter.WriteLine("#======================================================#")
            flFileWriter.WriteLine("")
            For Each oPair In colConfig
                flFileWriter.WriteLine(oPair.Key & " = " & oPair.Value)
            Next
            flFileWriter.Close()
        Catch ex As Exception

        Finally
            If Err.Number <> 0 Then
                SaveToLog(Err.Number & " - " & Err.Description)
            Else
                SaveToLog("New settings saved to RnRSettings.ini")
            End If
        End Try

    End Sub

    Public Sub SaveToLog(sText As String)

        Dim flFW As System.IO.StreamWriter
        Dim sLogFileName As String = colConfig("LogsDirectory") & "\" & Strings.Format(Now, "yyyyMMdd") & ".txt"

        Try
            If UCase(colConfig("LogsEnabled")) = "TRUE" Then
                If Not System.IO.Directory.Exists(colConfig("LogsDirectory")) Then System.IO.Directory.CreateDirectory(colConfig("LogsDirectory"))
                flFW = System.IO.File.AppendText(sLogFileName)
                flFW.WriteLine(Strings.Format(Now, "[HH:mm:ss] - ") & sText)
                flFW.Close()
            End If
        Catch ex As Exception
            'flFW.Close()
        End Try

    End Sub

    Private Sub LoadConfig()
        'loads config collection with saved values or default
        Dim sLine As String = ""
        Dim flFileReader As System.IO.StreamReader
        Dim sKey As String
        'Dim oPair As KeyValuePair(Of String, String)

        Try
            'load default settings into collection
            With colConfig
                'server applying settings
                .Add("PHPExecutableDirectory", System.Windows.Forms.Application.StartupPath & "\PHP") 'sets default PHP path to {AppInstallDirectory}\PHP
                .Add("ServerInterface", "0.0.0.0") ' listen on all interfaces as default
                .Add("ServerPort", "8000")
                .Add("PHPApplicationDirectory", System.Windows.Forms.Application.StartupPath & "\App") 'sets default aplication directory to {AppInstallDirectory}\App
                .Add("RunAsWindowsService", "false")
                .Add("WindowsServiceName", "Rock'n'Roll Server") 'used only when RunAsWindowsService is true
                'logs
                .Add("LogsEnabled", "false")
                .Add("LogsDirectory", System.Windows.Forms.Application.StartupPath & "\Logs") 'sets logs default directory to {SystemAppData}\Logs
                .Add("LogsKeepDays", "15") 'how many days logs are stored
                'viewer applying settings
                .Add("BrowserStartsWithBuiltInServer", "true") 'launches builin web serwer before web browser 
                .Add("BrowserStartsWithServerConsole", "false") 'launches builin PHP web serwer with visible output console
                .Add("Browser", "built-in") ' available values: built-in, customizedIE, default, IE, Chrome, Firefox, Opera, Safari
                .Add("BrowserStartOptions", "")
                .Add("BrowserNavigate2", "http://localhost")
                .Add("BrowserNavigate2Port", "8000")
                'setting for customized Internet explorer if selected
                .Add("CustomIE_AddressBar", "false")
                .Add("CustomIE_MenuBar", "false")
                .Add("CustomIE_ToolBar", "false")
                .Add("CustomIE_StatusBar", "false")
                .Add("CustomIE_Resizable", "true")
                .Add("CustomIE_Left", "80") ' -1 means IE default
                .Add("CustomIE_Top", "100")
                .Add("CustomIE_Width", "700")
                .Add("CustomIE_Height", "600")
                'settings for builtin web browser
                '.Add("BuiltInMyBrowser_Icon", "")
                .Add("BuiltInMyBrowser_Title", "Rock'nRoll Application")
                .Add("BuiltInMyBrowser_Logo", ".")
                .Add("BuiltInMyBrowser_Resizable", "true")
                .Add("BuiltInMyBrowser_StartMaximized", "false")
                .Add("BuiltInMyBrowser_Left", "-1") ' -1 means last used before close
                .Add("BuiltInMyBrowser_Top", "-1")
                .Add("BuiltInMyBrowser_Width", "-1")
                .Add("BuiltInMyBrowser_Height", "-1")
            End With

            'overwrite default values from RnRSettings.ini if file exists
            If System.IO.File.Exists(System.Windows.Forms.Application.StartupPath & "\RnRSettings.ini") Then
                'sSettings = System.IO.File.ReadAllText("RnRSettings.ini")
                flFileReader = System.IO.File.OpenText(System.Windows.Forms.Application.StartupPath & "\RnRSettings.ini")
                Do While Not flFileReader.EndOfStream
                    sLine = flFileReader.ReadLine
                    sLine = LTrim(sLine)
                    If Left(sLine, 1) <> "/" And Left(sLine, 1) <> ";" And Left(sLine, 1) <> "#" And InStr(sLine, "=") > 1 Then
                        sKey = Trim(Strings.Left(sLine, InStr(sLine, "=") - 1))
                        sLine = Strings.Replace(sLine, sKey, "")
                        sLine = Strings.Replace(sLine, "=", "")
                        sLine = Trim(sLine)
                        Try
                            colConfig.Remove(sKey)
                            colConfig.Add(sKey, sLine)
                        Catch ex As Exception

                        End Try
                    End If
                Loop
                flFileReader.Close()
            End If
        Catch ex As Exception
            'System.Diagnostics.EventLog.WriteEntry("RnR Service", "Commons error: " & Err.Description)
        End Try

    End Sub

End Class
