﻿Public NotInheritable Class SplashScreen

    'TODO: Ten formularz może być łatwo ustawiony jako ekran powitalny dla aplikacji przez przejście do karty „Aplikacja”
    '  Projektanta projektu („Właściwości” w menu „Projekt”).


    Private Sub SplashScreen1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim RnR As New Rock_n_Roll_Commons

        Try
            lblAppName.Text = RnR.SettingFor("BuiltInMyBrowser_Title")
            If Len(RnR.SettingFor("BuiltInMyBrowser_Logo")) > 4 Then
                If System.IO.File.Exists(RnR.SettingFor("BuiltInMyBrowser_Logo")) Then
                    Me.BackgroundImage = System.Drawing.Image.FromFile(RnR.SettingFor("BuiltInMyBrowser_Logo"))
                End If
            ElseIf System.IO.File.Exists("SplashScreen.jpg") Then
                Me.BackgroundImage = System.Drawing.Image.FromFile("SplashScreen.jpg")
            End If
            'Me.Refresh()
        Catch ex As Exception

        End Try

    End Sub

End Class
