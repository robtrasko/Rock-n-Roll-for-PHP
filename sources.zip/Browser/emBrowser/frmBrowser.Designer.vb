﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class emBrowser
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(emBrowser))
        Me.BrwBrowser = New System.Windows.Forms.WebBrowser()
        Me.TmrCheckProcesses = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'BrwBrowser
        '
        Me.BrwBrowser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BrwBrowser.Location = New System.Drawing.Point(0, 0)
        Me.BrwBrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.BrwBrowser.Name = "BrwBrowser"
        Me.BrwBrowser.ScriptErrorsSuppressed = True
        Me.BrwBrowser.Size = New System.Drawing.Size(697, 494)
        Me.BrwBrowser.TabIndex = 0
        '
        'TmrCheckProcesses
        '
        '
        'emBrowser
        '
        Me.ClientSize = New System.Drawing.Size(697, 494)
        Me.Controls.Add(Me.BrwBrowser)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "emBrowser"
        Me.ResumeLayout(False)

    End Sub

    'Friend WithEvents BrwBrowser As WebBrowser
    Friend WithEvents TmrCheckProcesses As Timer
    Friend WithEvents BrwBrowser As WebBrowser
    'Friend WithEvents Timer1 As Timer
End Class
